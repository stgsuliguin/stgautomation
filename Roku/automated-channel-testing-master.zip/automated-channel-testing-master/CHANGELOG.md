# **Roku Automated Channel Testing**
> 12.02.2019

## v.1.0.0

### Features

 * Initial Release.
 * Initial version of a Roku WebDriver.
 * Support for key press simulation.
 * UI testing capabilities.
 * Robot Framework support.
